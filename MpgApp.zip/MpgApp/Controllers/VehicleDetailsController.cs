﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using MpgApp.Models;

namespace MpgApp.Controllers
{
    public class VehicleDetailsController : Controller
    {
        private readonly MpgAppContext _context;

        public VehicleDetailsController(MpgAppContext context)
        {
            _context = context;
        }

        // GET: VehicleDetails
        public async Task<IActionResult> Index()
        {
            var mpgAppContext = _context.VehicleDetails.Include(v => v.Vehicle);
            return View(await mpgAppContext.ToListAsync());
        }

        // GET: VehicleDetails/Details/5
        public async Task<IActionResult> Details(DateTime? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var vehicleDetails = await _context.VehicleDetails
                .Include(v => v.Vehicle)
                .FirstOrDefaultAsync(m => m.DateFilled == id);
            if (vehicleDetails == null)
            {
                return NotFound();
            }

            return View(vehicleDetails);
        }

        // GET: VehicleDetails/Create
        public IActionResult Create()
        {
            ViewData["VehicleId"] = new SelectList(_context.VehicleRegistration, "VehicleId", "UserId");
            return View();
        }

        // POST: VehicleDetails/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("DateFilled,GallonsReplaced,MilesDriven,VehicleId")] VehicleDetails vehicleDetails)
        {
            if (ModelState.IsValid)
            {
                _context.Add(vehicleDetails);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["VehicleId"] = new SelectList(_context.VehicleRegistration, "VehicleId", "UserId", vehicleDetails.VehicleId);
            return View(vehicleDetails);
        }

        // GET: VehicleDetails/Edit/5
        public async Task<IActionResult> Edit(DateTime? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var vehicleDetails = await _context.VehicleDetails.FindAsync(id);
            if (vehicleDetails == null)
            {
                return NotFound();
            }
            ViewData["VehicleId"] = new SelectList(_context.VehicleRegistration, "VehicleId", "UserId", vehicleDetails.VehicleId);
            return View(vehicleDetails);
        }

        // POST: VehicleDetails/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(DateTime id, [Bind("DateFilled,GallonsReplaced,MilesDriven,VehicleId")] VehicleDetails vehicleDetails)
        {
            if (id != vehicleDetails.DateFilled)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(vehicleDetails);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!VehicleDetailsExists(vehicleDetails.DateFilled))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["VehicleId"] = new SelectList(_context.VehicleRegistration, "VehicleId", "UserId", vehicleDetails.VehicleId);
            return View(vehicleDetails);
        }

        // GET: VehicleDetails/Delete/5
        public async Task<IActionResult> Delete(DateTime? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var vehicleDetails = await _context.VehicleDetails
                .Include(v => v.Vehicle)
                .FirstOrDefaultAsync(m => m.DateFilled == id);
            if (vehicleDetails == null)
            {
                return NotFound();
            }

            return View(vehicleDetails);
        }

        // POST: VehicleDetails/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(DateTime id)
        {
            var vehicleDetails = await _context.VehicleDetails.FindAsync(id);
            _context.VehicleDetails.Remove(vehicleDetails);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool VehicleDetailsExists(DateTime id)
        {
            return _context.VehicleDetails.Any(e => e.DateFilled == id);
        }
    }
}
