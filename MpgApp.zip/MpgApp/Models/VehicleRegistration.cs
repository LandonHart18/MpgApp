﻿using System;
using System.Collections.Generic;

namespace MpgApp.Models
{
    public partial class VehicleRegistration
    {
        public VehicleRegistration()
        {
            VehicleDetails = new HashSet<VehicleDetails>();
        }

        public int VehicleId { get; set; }
        public string VehicleMake { get; set; }
        public string VehicleModel { get; set; }
        public int VehicleYear { get; set; }
        public string UserId { get; set; }

        //public virtual AspNetUsers User { get; set; }
        public virtual ICollection<VehicleDetails> VehicleDetails { get; set; }
    }
}
