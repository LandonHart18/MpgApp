﻿using System;
using System.Collections.Generic;

namespace MpgApp.Models
{
    public partial class VehicleDetails
    {
        public DateTime DateFilled { get; set; }
        public int GallonsReplaced { get; set; }
        public int MilesDriven { get; set; }
        public int VehicleId { get; set; }

        public virtual VehicleRegistration Vehicle { get; set; }
    }
}
